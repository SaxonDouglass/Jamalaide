Matt and Chris Readme
-----------------
Matt and Chris
Author:         Christopher Johnson
Release Date:   November 20th 2011

Authors Note
-----------------
This game was created during the Adelaide Game Jam(Jamalaide)
held on from 10pm 19th of November till 6pm 20th of November.

This game was designed using Love2D and is based upon the
relationship between myself and fellow jammer @Orann.

Special thanks goes out to Jamalaide organisers for putting
on a great event as well as Alex Mackay and Harriet Lloyd
for helping play test and put together the maths for The
difficulty curve. 

License
-----------------
The source code, game and image assets are under the
CC-GNU-GPL 3.0 license. You can read the license in gpl.txt.

The sound effects were sourced from FreeSounds.org and hence
belong to their respective authors.
http://www.freesound.org/people/johnnypanic/sounds/36278/
http://www.freesound.org/people/johnnypanic/sounds/36281/
http://www.freesound.org/people/johnnypanic/sounds/36284/
http://www.freesound.org/people/johnnypanic/sounds/36279/

Warranty
-----------------
No warranty is provided with this software. You use it at your own risk.

Feedback
-----------------
Feel free to send any feedback to chris@cjohnson.id.au or you can leave
your comments at http://www.cjohnson.id.au
