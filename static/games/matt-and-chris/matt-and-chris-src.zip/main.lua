require("vector.lua")

SCREEN_X1 = 0
SCREEN_X2 = 640
SCREEN_Y1 = 0
SCREEN_Y2 = 480

BARRIER = 30

WORLD_X1 = SCREEN_X1 + BARRIER
WORLD_X2 = SCREEN_X2 - BARRIER
WORLD_Y1 = SCREEN_Y1 + BARRIER
WORLD_Y2 = SCREEN_Y2 - BARRIER

PLAYER_DIM = 24
PLAYER_VELOCITY = 160
PLAYER_DIAG_DIFF = 0.8
PLAYER_HITBOX_PADDING = 3
ENEMY_DIM = 24

ENEMY_VELOCITY = 120.0
MAX_ENEMY_COUNT = 40

ENEMY_START_INTERVAL = 1.2
START_SPAWN_DECREASE = 0.05
SPAWN_DECAY = 0.005 -- percentage

STATE_INTRO    = 0
STATE_PLAY     = 1
STATE_GAMEOVER = 2

function love.load()
    math.randomseed(os.time())

    backgroundQuad = love.graphics.newQuad(0, 0, SCREEN_X2, SCREEN_Y2, SCREEN_X2, SCREEN_Y2)
    backgroundGraphic = love.graphics.newImage("img/background.png");

    playerQuad = love.graphics.newQuad(0, 0, PLAYER_DIM, PLAYER_DIM, PLAYER_DIM, PLAYER_DIM)
    player1Graphic = love.graphics.newImage("img/player1.png")
    player2Graphic = love.graphics.newImage("img/player2.png")

    enemyQuad = love.graphics.newQuad(0, 0, ENEMY_DIM, ENEMY_DIM, ENEMY_DIM, ENEMY_DIM)
    enemyGraphic1 = love.graphics.newImage("img/enemy1.png")
    enemyBitGraphic1 = love.graphics.newImage("img/enemy1Part.png")

    enemyGraphic2 = love.graphics.newImage("img/enemy2.png")
    enemyBitGraphic2 = love.graphics.newImage("img/enemy2Part.png")

    gameOverQuad = love.graphics.newQuad(0, 0, 300, 100, 300, 100)
    gameOverGraphic = love.graphics.newImage("img/gameOverPanel.png")

    pauseQuad = love.graphics.newQuad(0, 0, 300, 100, 300, 100)
    pauseGraphic = love.graphics.newImage("img/pausePanel.png")

    introQuad = love.graphics.newQuad(0, 0, 440, 340, 440, 340)
    introGraphic = love.graphics.newImage("img/introPanel.png");

    playerDieSound = love.audio.newSource("sfx/playersDie.ogg", "static")
    enemyDieP1Sound = love.audio.newSource("sfx/enemyDieP1.ogg", "static")
    enemyDieP2Sound = love.audio.newSource("sfx/enemyDieP2.ogg", "static")
    enterSound = love.audio.newSource("sfx/enter.ogg", "static")

    love.graphics.setBackgroundColor(255, 255, 255)
    particles = {}

    highScore = 0
    startGame()
    state = STATE_INTRO
end

function startGame()
    player1X = (WORLD_X1 + WORLD_X2 - PLAYER_DIM)/2.0 - 2 * PLAYER_DIM
    player1Y = (WORLD_Y1 + WORLD_Y2 - PLAYER_DIM)/2.0

    player2X = (WORLD_X1 + WORLD_X2 - PLAYER_DIM)/2.0 + 2 * PLAYER_DIM
    player2Y = (WORLD_Y1 + WORLD_Y2 - PLAYER_DIM)/2.0

    particles = {}
    enemies1 = {}
    enemies2 = {}
    enemyTime = 0
    enemiesKilled = 0
    isPaused = false;
    gameTime = 0

    hasHighScore = false 
    showPlayer1 = true 
    showPlayer2 = true 

    enemyAddInterval = ENEMY_START_INTERVAL
    spawnInterval = START_SPAWN_DECREASE

    state = STATE_PLAY
end

function love.update(dt)
    if isPaused == true then
        return
    end

    for particleIdx in pairs(particles) do 
        particles[particleIdx]:update(dt)
    end

    if state == STATE_INTRO then
        updateIntro(dt)
    elseif state == STATE_PLAY then
        updatePlay(dt)  
    else
        updateGameOver(dt)
    end
end

function updateIntro(dt)
end

function updatePlay(dt)
    gameTime = gameTime + dt

    -- Player 1
    if love.keyboard.isDown('a') == true then
        if love.keyboard.isDown('w') == true or love.keyboard.isDown('s') == true then
            player1X = player1X - dt * PLAYER_VELOCITY * PLAYER_DIAG_DIFF
        else 
            player1X = player1X - dt * PLAYER_VELOCITY
        end
    end

    if love.keyboard.isDown('d') == true then
        if love.keyboard.isDown('w') == true or love.keyboard.isDown('s') == true then
            player1X = player1X + dt * PLAYER_VELOCITY * PLAYER_DIAG_DIFF
        else
            player1X = player1X + dt * PLAYER_VELOCITY
        end
    end

    if love.keyboard.isDown('w') == true then
        if love.keyboard.isDown('a') == true or love.keyboard.isDown('d') == true then
            player1Y = player1Y - dt * PLAYER_VELOCITY * PLAYER_DIAG_DIFF
        else
            player1Y = player1Y - dt * PLAYER_VELOCITY
        end
    end

    if love.keyboard.isDown('s') == true then
        if love.keyboard.isDown('a') == true or love.keyboard.isDown('d') == true then
            player1Y = player1Y + dt * PLAYER_VELOCITY * PLAYER_DIAG_DIFF
        else
            player1Y = player1Y + dt * PLAYER_VELOCITY
        end
    end

    if player1X < WORLD_X1 then
        player1X = WORLD_X1
    elseif player1X > WORLD_X2 - PLAYER_DIM then
        player1X = WORLD_X2 - PLAYER_DIM
    end

    if player1Y < WORLD_Y1 then
        player1Y = WORLD_Y1
    elseif player1Y > WORLD_Y2 - PLAYER_DIM then
        player1Y = WORLD_Y2 - PLAYER_DIM
    end

    -- Player 2
    if love.keyboard.isDown('left') == true then
        if love.keyboard.isDown('up') == true or love.keyboard.isDown('down') == true then
            player2X = player2X - dt * PLAYER_VELOCITY * PLAYER_DIAG_DIFF
        else 
            player2X = player2X - dt * PLAYER_VELOCITY
        end
    end

    if love.keyboard.isDown('right') == true then
        if love.keyboard.isDown('up') == true or love.keyboard.isDown('down') == true then
            player2X = player2X + dt * PLAYER_VELOCITY * PLAYER_DIAG_DIFF
        else
            player2X = player2X + dt * PLAYER_VELOCITY
        end
    end

    if love.keyboard.isDown('up') == true then
        if love.keyboard.isDown('left') == true or love.keyboard.isDown('right') == true then
            player2Y = player2Y - dt * PLAYER_VELOCITY * PLAYER_DIAG_DIFF
        else
            player2Y = player2Y - dt * PLAYER_VELOCITY
        end
    end

    if love.keyboard.isDown('down') == true then
        if love.keyboard.isDown('left') == true or love.keyboard.isDown('right') == true then
            player2Y = player2Y + dt * PLAYER_VELOCITY * PLAYER_DIAG_DIFF
        else
            player2Y = player2Y + dt * PLAYER_VELOCITY
        end
    end

    if player2X < WORLD_X1 then
        player2X = WORLD_X1
    elseif player2X > WORLD_X2 - PLAYER_DIM then
        player2X = WORLD_X2 - PLAYER_DIM
    end

    if player2Y < WORLD_Y1 then
        player2Y = WORLD_Y1
    elseif player2Y > WORLD_Y2 - PLAYER_DIM then
        player2Y = WORLD_Y2 - PLAYER_DIM
    end

    if rectInRect(player1X + PLAYER_HITBOX_PADDING, player1Y + PLAYER_HITBOX_PADDING, PLAYER_DIM - PLAYER_HITBOX_PADDING, PLAYER_DIM - PLAYER_HITBOX_PADDING, player2X + PLAYER_HITBOX_PADDING, player2Y + PLAYER_HITBOX_PADDING, PLAYER_DIM - PLAYER_HITBOX_PADDING, PLAYER_DIM - PLAYER_HITBOX_PADDING) == true then
        state = STATE_GAMEOVER
        playerDieSound:play()

        showPlayer1 = false
        generatePlayerParticles(enemyBitGraphic1, player1X, player1Y);

        showPlayer2 = false
        generatePlayerParticles(enemyBitGraphic2, player2X, player2Y);
    end

    ----------------------
    -- Add enemies
    ----------------------
    enemyTime = enemyTime + dt
    if enemyTime > enemyAddInterval then
        totalEnemies = table.getn(enemies1) + table.getn(enemies2)
        if totalEnemies < MAX_ENEMY_COUNT then
            -- Choose a random side of the screen to move from
            side = math.random(0, 3)
            enemyX = 0
            enemyY = 0

            if side == 0 then
                enemyX = -PLAYER_DIM
                enemyY = math.random(SCREEN_X1 + ENEMY_DIM/2.0, SCREEN_X2 - ENEMY_DIM/2.0)
            elseif side == 1 then
                enemyX = PLAYER_DIM + SCREEN_X2
                enemyY = math.random(SCREEN_X1 + ENEMY_DIM/2.0, SCREEN_X2 - ENEMY_DIM/2.0)
            elseif side == 2 then
                enemyX = math.random(SCREEN_X1 + ENEMY_DIM/2.0, SCREEN_X2 - ENEMY_DIM/2.0)
                enemyY = -PLAYER_DIM
            elseif side == 3 then
                enemyX = math.random(SCREEN_X1 + ENEMY_DIM/2.0, SCREEN_X2 - ENEMY_DIM/2.0)
                enemyY = PLAYER_DIM + SCREEN_Y2
            end
             
            -- Choose a type of enemy
            local type = math.random(1,2)
            list = nil
            if type == 1 then
                list = enemies1
            elseif type == 2 then
                list = enemies2
            end
            table.insert(list, {x = enemyX, y = enemyY})
        end
        enemyTime = enemyTime - enemyAddInterval
        enemyAddInterval = 1.2 * math.pow(2, -0.01 * gameTime)
    end

    ----------------------
    -- Move Enemies
    ----------------------
    for enemyIdx in pairs(enemies1) do 
        --Find the direction that needs to be taken
        local dirX = player2X + PLAYER_DIM/2.0 - enemies1[enemyIdx].x
        local dirY = player2Y + PLAYER_DIM/2.0 - enemies1[enemyIdx].y
        
        vec = Vector:create(dirX, dirY)
        vec:normalise()

        local xMvAmount = math.abs(vec:getX()) / (math.abs(vec:getX()) + math.abs(vec:getY()))
        local yMvAmount = math.abs(vec:getY()) / (math.abs(vec:getX()) + math.abs(vec:getY()))

        enemies1[enemyIdx].x = enemies1[enemyIdx].x + vec:getX() * ENEMY_VELOCITY * dt * xMvAmount;
        enemies1[enemyIdx].y = enemies1[enemyIdx].y + vec:getY() * ENEMY_VELOCITY * dt * yMvAmount;
    end

    for enemyIdx in pairs(enemies2) do 
        --Find the direction that needs to be taken
        local dirX = player1X + PLAYER_DIM/2.0 - enemies2[enemyIdx].x
        local dirY = player1Y + PLAYER_DIM/2.0 - enemies2[enemyIdx].y
        
        vec = Vector:create(dirX, dirY)
        vec:normalise()

        local xMvAmount = math.abs(vec:getX()) / (math.abs(vec:getX()) + math.abs(vec:getY()))
        local yMvAmount = math.abs(vec:getY()) / (math.abs(vec:getX()) + math.abs(vec:getY()))

        enemies2[enemyIdx].x = enemies2[enemyIdx].x + vec:getX() * ENEMY_VELOCITY * dt * xMvAmount;
        enemies2[enemyIdx].y = enemies2[enemyIdx].y + vec:getY() * ENEMY_VELOCITY * dt * yMvAmount;
    end

    ----------------------
    -- Handle collisions
    ----------------------
    -- Check Game Over First
    for enemyIdx in pairs(enemies1) do 
        if circleInRect(enemies1[enemyIdx].x, enemies1[enemyIdx].y, ENEMY_DIM/2.0, player2X + PLAYER_HITBOX_PADDING, player2Y + PLAYER_HITBOX_PADDING, PLAYER_DIM - PLAYER_HITBOX_PADDING , PLAYER_DIM - PLAYER_HITBOX_PADDING) == true then
            state = STATE_GAMEOVER 
            playerDieSound:play()
            showPlayer2 = false

            generatePlayerParticles(enemyBitGraphic2, player2X, player2Y);
        end 
    end

    for enemyIdx in pairs(enemies2) do 
        if circleInRect(enemies2[enemyIdx].x, enemies2[enemyIdx].y, ENEMY_DIM/2.0, player1X + PLAYER_HITBOX_PADDING, player1Y + PLAYER_HITBOX_PADDING, PLAYER_DIM - PLAYER_HITBOX_PADDING, PLAYER_DIM - PLAYER_HITBOX_PADDING) == true then
            state = STATE_GAMEOVER 
            playerDieSound:play()
            showPlayer1 = false

            generatePlayerParticles(enemyBitGraphic1, player1X, player1Y);
        end
    end

    -- Now check for removals
    local aP1EnemyDies = false
    for enemyIdx in pairs(enemies1) do 
        if circleInRect(enemies1[enemyIdx].x, enemies1[enemyIdx].y, ENEMY_DIM/2.0, player1X + PLAYER_HITBOX_PADDING, player1Y + PLAYER_HITBOX_PADDING, PLAYER_DIM - PLAYER_HITBOX_PADDING, PLAYER_DIM - PLAYER_HITBOX_PADDING) == true then
            increaseKill()
            generateEnemyParticles(enemyBitGraphic1, enemies1[enemyIdx].x, enemies1[enemyIdx].y)
            table.remove(enemies1, enemyIdx)
            aP1EnemyDies = true 
        end 
    end

    if aP1EnemyDies == true then
        enemyDieP1Sound:stop()
        enemyDieP1Sound:play()
    end 

    local aP2EnemyDies = false
    for enemyIdx in pairs(enemies2) do 
        if circleInRect(enemies2[enemyIdx].x, enemies2[enemyIdx].y, ENEMY_DIM/2.0, player2X + PLAYER_HITBOX_PADDING, player2Y + PLAYER_HITBOX_PADDING, PLAYER_DIM - PLAYER_HITBOX_PADDING, PLAYER_DIM - PLAYER_HITBOX_PADDING) == true then
            increaseKill()
            generateEnemyParticles(enemyBitGraphic2, enemies2[enemyIdx].x, enemies2[enemyIdx].y)
            table.remove(enemies2, enemyIdx)
            aP2EnemyDies = true 
        end 
    end

    if aP2EnemyDies == true then
        enemyDieP2Sound:stop()
        enemyDieP2Sound:play()
    end 
end

function updateGameOver(dt)
end

function love.draw()
    love.graphics.drawq(backgroundGraphic, backgroundQuad, 0, 0)
    if showPlayer1 == true then
        love.graphics.drawq(player1Graphic, playerQuad, player1X, player1Y)
    end

    if showPlayer2 == true then
        love.graphics.drawq(player2Graphic, playerQuad, player2X, player2Y)
    end

    for enemyIdx in pairs(enemies1) do 
        love.graphics.drawq(enemyGraphic1, enemyQuad, enemies1[enemyIdx].x - ENEMY_DIM /2.0, enemies1[enemyIdx].y - ENEMY_DIM /2.0)
    end

    for enemyIdx in pairs(enemies2) do 
        love.graphics.drawq(enemyGraphic2, enemyQuad, enemies2[enemyIdx].x - ENEMY_DIM /2.0, enemies2[enemyIdx].y - ENEMY_DIM /2.0)
    end

    for particleIdx in pairs(particles) do 
        love.graphics.draw(particles[particleIdx], 0, 0)
    end

    love.graphics.setColor(30, 30, 30)
    love.graphics.print("Enemies Killed: "..enemiesKilled, 8, 8) 

    if hasHighScore == true then
        love.graphics.setColor(0, 0x99, 0)
    end
    love.graphics.print("High Score: "..highScore, 530, 8) 
    love.graphics.setColor(255, 255, 255)

    if state == STATE_INTRO then
        love.graphics.drawq(introGraphic, introQuad, 100, 70)
        love.graphics.setColor(30, 30, 30)
        love.graphics.print("Toggle Fullscreen - F", 160, 460)
        love.graphics.print("Pause - Tab", 360, 460)
        love.graphics.setColor(255, 255, 255)
    elseif state == STATE_GAMEOVER then
        love.graphics.drawq(gameOverGraphic, gameOverQuad, 170, 190)
    else
        if isPaused == true then
            love.graphics.drawq(pauseGraphic, pauseQuad, 170, 190)
        end
    end
end

function love.keypressed(key, unicode)
    if key == ' ' then
        if state == STATE_INTRO then
            state = STATE_PLAY
            enterSound:play()
        elseif state == STATE_GAMEOVER then
            startGame()
            enterSound:play()
        end
    elseif key == 'f' then
        love.graphics.toggleFullscreen()
    end
end

function love.keyreleased(key, unicode)
   if key == 'escape' then
        love.event.push('q')
   elseif key == 'tab' and state == STATE_PLAY then
        if isPaused == true then
            isPaused = false 
        elseif isPaused == false then
            isPaused = true 
        end
   end
end

function love.focus(f)
    if f == true then
        isPaused = false
    else
        isPaused = true
    end
end

function love.quit()
end

function circleInRect(circleX, circleY, circleRadius, rectX, rectY, rectWidth, rectHeight)
    circleDistanceX = math.abs(circleX - rectX - rectWidth/2.0)
    circleDistanceY = math.abs(circleY - rectY - rectHeight/2.0)

    if circleDistanceX > (rectWidth/2 + circleRadius) then
        return false
    end

    if circleDistanceY > (rectHeight/2 + circleRadius) then
        return false
    end

    if circleDistanceX <= (rectWidth/2) then
        return true
    end

    if circleDistanceY <= (rectHeight/2) then
        return true
    end

    cornerDistance_sq = math.pow(circleDistanceX - rectWidth/2, 2) + math.pow(circleDistanceY - rectHeight/2,2)
    return cornerDistance_sq <= math.pow(circleRadius, 2)
end

function rectInRect(rect1x, rect1y, rect1w, rect1h, rect2x, rect2y, rect2w, rect2h)
    local leftA
    local leftB
    local rightA
    local rightB
    local topA
    local topB
    local bottomA
    local bottomB

    leftA = rect1x;
    rightA = rect1x + rect2w;
    topA = rect1y;
    bottomA = rect1y + rect2h;
        
    -- Calculate the sides of rect B
    leftB = rect2x;
    rightB = rect2x + rect2w;
    topB = rect2y;
    bottomB = rect2y + rect2h;

    if bottomA <= topB then
        return false;
    end
    
    if topA >= bottomB then
        return false;
    end
    
    if rightA <= leftB then
        return false
    end
    
    if leftA >= rightB then
        return false;
    end
    
    -- If none of the sides from A are outside B
    return true;
end

function generateEnemyParticles(graphic, x, y)
    enemyParticles = love.graphics.newParticleSystem(graphic, 64)
    enemyParticles:setEmissionRate(100)
    enemyParticles:setSpeed(200, 200)
    enemyParticles:setGravity(0)
    enemyParticles:setSize(2.5, 0)
    enemyParticles:setColor(255, 255, 255, 255, 255, 255, 255, 0)
    enemyParticles:setPosition(x, y)
    enemyParticles:setLifetime(0.5)
    enemyParticles:setParticleLife(0.5)
    enemyParticles:setDirection(0)
    enemyParticles:setSpread(360)
    enemyParticles:setRadialAcceleration(-1000)
    enemyParticles:setTangentialAcceleration(0)
    enemyParticles:start()
    table.insert(particles, enemyParticles)
end

function generatePlayerParticles(graphic, x, y)
    playerParticles = love.graphics.newParticleSystem(graphic, 128)
    playerParticles:setEmissionRate(128)
    playerParticles:setSpeed(300, 300)
    playerParticles:setGravity(0)
    playerParticles:setSize(5, 0)
    playerParticles:setColor(255, 255, 255, 255, 255, 255, 255, 0)
    playerParticles:setPosition(x + PLAYER_DIM/2.0, y+ PLAYER_DIM/2.0)
    playerParticles:setLifetime(0.5)
    playerParticles:setParticleLife(0.5)
    playerParticles:setDirection(0)
    playerParticles:setSpread(360)
    playerParticles:setRadialAcceleration(-1000)
    playerParticles:setTangentialAcceleration(0)
    playerParticles:start()
    table.insert(particles, playerParticles)
end

function increaseKill()
    enemiesKilled = enemiesKilled + 1
    if enemiesKilled > highScore then
        highScore = enemiesKilled
        hasHighScore = true
    end
end
