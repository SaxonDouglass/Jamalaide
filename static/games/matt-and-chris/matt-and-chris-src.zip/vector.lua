Vector = {}
Vector.__index = Vector

function Vector:create(x_, y_)
	local temp = {}
	setmetatable(temp, Vector)
	temp.data = {x = x_, y = y_ }
	return temp
end

function Vector:normalise()
    self.data.x = self.data.x / self:length()
    self.data.y = self.data.y / self:length()
end

function Vector:length()
   return math.sqrt(self.data.x * self.data.x + self.data.y * self.data.y)
end

function Vector:getX()
    return self.data.x
end

function Vector:getY()
    return self.data.y
end
